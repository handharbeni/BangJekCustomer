package com.bangjeck.setting;

import android.support.v7.app.AppCompatActivity;

public class BangJeckSetting extends AppCompatActivity{
    public static String base_url  = "http://31.220.53.148/bangjeck/";
    public static boolean show_history  = false;
    public static boolean show_notif    = false;

    public static String kode_transaksi = "";
    public static String kode_status    = "";

    public static String dari       = "";
    public static String pesan      = "";
    public static String tanggal    = "";
    public static int status        = 0;
}