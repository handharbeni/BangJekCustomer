package com.bangjeck.stucture;

public class ItemData {
    String description;

    public ItemData(String description){
        this.description    = description;
    }

    public String getDescription(){
        return description;
    }
}
